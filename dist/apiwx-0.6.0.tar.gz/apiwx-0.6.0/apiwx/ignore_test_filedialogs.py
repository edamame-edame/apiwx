from __init__ import *


class FileDialogTester(
    App[Singleton,
        DetectWindow]):
    """ A tester class for file dialog functionalities."""
    def __init__(self):
        super().__init__(
            "FileDialog testapp"
        )


    class FileDialogTestWindow(
        Window[Singleton,
               ByPanelSize,
               FixSize,
               DetectPanel]):
        """ A test window for file dialog functionalities."""
        def __init__(self, app: 'FileDialogTester'):
            super().__init__(
                app,
                title="FileDialog Test Window",
                size=(600, 800),
                pos=(100, 100)
            )

            self.show()


        class TestPanel(
            Panel[Singleton,
                  DetectChildren]):
            """ A test panel for file dialog functionalities."""
            def __init__(self, window: 'FileDialogTester.FileDialogTestWindow'):
                super().__init__(
                    window,
                    size=window.size,
                    pos=(0, 0),
                )


            class TopSelectionPanel(
                Panel[Singleton,
                      DetectChildren]):
                """ A top selection panel for file dialog tests."""
                def __init__(self, parent: 'FileDialogTester.FileDialogTestWindow.TestPanel'):
                    super().__init__(
                        parent,
                        size=(parent.size[0], 40),
                        pos=(0, 0)
                    )

                
                class OpenFileDialogButton(
                    Button[Singleton,
                           DetectChildren]):
                    """ A button to open the file dialog."""
                    def __init__(self, parent: 'FileDialogTester.FileDialogTestWindow.TestPanel.TopSelectionPanel'):
                        super().__init__(
                            parent,
                            label="Open File Dialog",
                            size=(180, 30),
                            pos=(5, 5)
                        )

                        self.slots_on_click << self.on_click

                    def on_click(self, event):
                        """ Handle button click to open file dialog."""
                        with OpenFileDialog(
                            title="Select a file to open",
                            initial_directory="C:/",
                            filter="All Files|*.*|Text Files|*.txt") as dialog:
                            
                            if dialog.show_dialog() == DialogResult.OK:
                                selected_files = dialog.filenames
                                print("Selected files:", selected_files)

                            else:
                                print("File dialog canceled.")

                    
                class SaveFileDialogButton(
                    Button[Singleton,
                           DetectChildren]):
                    """ A button to open the file dialog."""
                    def __init__(self, parent: 'FileDialogTester.FileDialogTestWindow.TestPanel.TopSelectionPanel'):
                        super().__init__(
                            parent,
                            label="Save File Dialog",
                            size=(180, 30),
                            pos=(185, 5)
                        )

                        self.slots_on_click << self.on_click

                    def on_click(self, event):
                        """ Handle button click to open file dialog."""
                        dialog: SaveFileDialog

                        with SaveFileDialog(
                            title="Select a file to save",
                            initial_directory="C:/",
                            filter="All Files|*.*|Text Files|*.txt") as dialog:
                            
                            if dialog.show_dialog() == DialogResult.OK:
                                selected_files = dialog.filenames
                                print("Selected files:", selected_files)

                            else:
                                print("File dialog canceled.")


                class FolderBrowserDialogButton(
                    Button[Singleton,
                           DetectChildren]):
                    """ A button to open the folder browser dialog."""
                    def __init__(self, parent: 'FileDialogTester.FileDialogTestWindow.TestPanel.TopSelectionPanel'):
                        super().__init__(
                            parent,
                            label="Folder Browser Dialog",
                            size=(180, 30),
                            pos=(365, 5)
                        )

                        self.slots_on_click << self.on_click

                    def on_click(self, event):
                        """ Handle button click to open folder browser dialog."""
                        dialog: FolderBrowserDialog

                        with FolderBrowserDialog(
                            title="Select a folder",
                            default_path="C:/") as dialog:

                            
                            if dialog.show_dialog() == DialogResult.OK:
                                selected_folders = dialog.selected_path
                                print("Selected folders:", selected_folders)

                            else:
                                print("Folder dialog canceled.")


if __name__ == "__main__":
    test_app = FileDialogTester()

    test_app.mainloop()