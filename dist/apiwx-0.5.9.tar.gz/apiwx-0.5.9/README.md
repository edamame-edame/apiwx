

# ## 🎉 What's New in v0.5.9

- **📦 WrappedBoxSizer Export**: Added WrappedBoxSizer to public API exports in __init__.py for improved layout management
- **🔧 Enhanced Layout Support**: Developers can now import and use WrappedBoxSizer directly from the main package
- **💡 Better Developer Experience**: Complete layout toolkit with PEP 8 compliant BoxSizer wrapper for intuitive GUI design
- **⚡ Simplified Imports**: Access all core layout components including sizers through the main apiwx package

### Previous in v0.5.8

- **🔧 Fixed Mixins Alias Classes**: Resolved NotImplementationError issues during instantiation of alias classes
- **✅ Improved Class Inheritance**: All alias classes now use proper class inheritance instead of overload methods
- **🛠️ Enhanced Parameter Handling**: Fixed None parameter handling in Window and Panel alias classes to prevent runtime errors
- **🧪 Comprehensive Testing**: Added thorough test coverage for all alias class instantiation scenarios
- **⚡ Better Stability**: Improved overall stability and reliability of the mixin alias system

### Previous in v0.5.7

- **📋 MutableListView Component**: New dynamic list management system with panel-based UI components
- **🔀 AbstractMutableListNode**: Base class for creating dynamic list items with Multiton mixin support
- **📱 Scrollable List Interface**: Full scrolling support with customizable scroll rates and styling
- **🔧 Enhanced LocateByParent**: Improved size calculation and automatic text repositioning with SetText method
- **💡 Better IDE Support**: Enhanced type hints and overload definitions across mixin system for improved development experience
- **⚙️ Flexible Node Management**: Easy append/remove operations with automatic panel layout and refresh

### Previous in v0.5.6

- **📍 StaticText Positioning Mixins**: New `mixins_statictext.py` module with intelligent text positioning capabilities
- **🎯 Nine Alignment Options**: Complete text alignment system (top-left, center, bottom-right, etc.) with `TextAlign` enum
- **🔄 Dynamic Positioning**: `LocateByParent` mixin automatically positions text within parent windows
- **📏 Smart Layout Management**: Automatic text repositioning with parent window resizing support
- **🎨 Flexible API**: Support both string-based ("c", "tl") and enum-based (TextAlign.CENTER) alignment specification

### Previous in v0.5.5

- **🏷️ Comprehensive Type Aliases**: New `mixins_alias.py` module with 12 convenient type aliases for common mixin combinations
- **📚 Complete Documentation**: All type aliases include detailed docstrings, usage examples, and parameter documentation
- **🎯 Development Efficiency**: Pre-configured classes like `AppBase`, `WindowWithPanel`, `PanelDetectChildren` for rapid development
- **🔧 Enhanced Panel Transitions**: Improved `paneltransmodel.py` with better documentation and cleaner API patterns
- **💡 Better Developer Experience**: IntelliSense support for mixin parameters with real instantiable classes

### Previous in v0.5.4

- **🔍 Child Indexor Search**: New `search_child_indexor()` method for AutoDetect mixin
- **📦 Singleton/Multiton Support**: Retrieve UI object indexors for both single and multiple components
- **🔧 Enhanced Instance Detection**: Improved runtime detection of instance attributes in addition to class attributes  
- **💡 Developer Flexibility**: Easy access to dynamically created UI components through indexor tuples
- **📝 Comprehensive Type Support**: Full type stubs for enhanced IDE integration and autocomplete

### Previous in v0.5.3

- **🗃️ C#-Style File Dialogs**: Complete OpenFileDialog, SaveFileDialog, and FolderBrowserDialog implementation
- **🔄 Familiar APIs**: C# Windows Forms compatible dialog patterns for seamless transition
- **⚙️ Comprehensive Features**: Single/multiple file selection, file filters, overwrite protection
- **📝 Enhanced Documentation**: Complete examples and usage patterns for file dialog functionality
- **🚀 Developer Experience**: Intuitive property-based configuration matching C# conventions
**apiwx** is a modern, user-friendly wrapper for wxPython that makes GUI development easier and more intuitive. It provides simplified APIs, automatic component management, powerful **mixin system**, comprehensive message boxes, **integrated type stubs**, and comprehensive Python version compatibility testing.

## 🎉 What's New in v0.5.3

- **� C#-Style File Dialogs**: Complete OpenFileDialog, SaveFileDialog, and FolderBrowserDialog implementation
- **� Familiar APIs**: C# Windows Forms compatible dialog patterns for seamless transition
- **�️ Comprehensive Features**: Single/multiple file selection, file filters, overwrite protection
- **📝 Enhanced Documentation**: Complete examples and usage patterns for file dialog functionality
- **� Developer Experience**: Intuitive property-based configuration matching C# conventions

## Quick Start

### Installation

```bash
pip install apiwx
```

The installation automatically includes complete type stubs for full IDE support - no additional packages needed!

### Requirements

- Python 3.11 or higher (recommended)
- Python 3.12+ fully supported and tested
- wxPython 4.2.0 or higher (automatically installed with apiwx)

> **Note**: apiwx uses modern Python type annotations and union operators that require Python 3.11+ for full compatibility. Python 3.10 is not currently supported due to advanced type annotation features used throughout the codebase.

### Your First App

```python
import apiwx

# Create a simple app with just a few lines
app = apiwx.WrappedApp("My First App")
window = apiwx.WrappedWindow(app, title="Hello World", size=(400, 300))
panel = apiwx.WrappedPanel(window)
button = apiwx.WrappedButton(panel, label="Click Me!", pos=(150, 100))

# Add button functionality
def on_click(event):
    apiwx.show_info("Hello from apiwx!")

button.slots_on_click += on_click

app.mainloop()
```

## Key Features

### 🚀 **Integrated Type Stubs (New in v0.5.1)**
apiwx now includes **built-in type stubs** that are automatically installed:

- **Zero Configuration**: Type stubs included in main package - no separate installation needed
- **Universal VSCode Support**: "Go to Definition" (F12) shows clean type stubs across all environments
- **PEP 561 Compliance**: Full compatibility with mypy, pylance, pyright, and other type checkers
- **Complete Coverage**: 21 comprehensive type stub files covering all modules and mixins
- **Intelligent Class Definitions**: Real instantiable classes for mixin aliases with full parameter support

```python
# Full type support with new convenient aliases (v0.5.5)
from apiwx.mixins_alias import AppBase, WindowWithPanel, PanelDetectChildren

app: AppBase = AppBase("MyApp")
window: WindowWithPanel = WindowWithPanel(app, title="Demo")
panel: PanelDetectChildren = PanelDetectChildren(
    window,
    size=(400, 300),    # <- Auto-completed with type hints
    color=(255, 255, 255),  # <- Type checked
    style=0             # <- Full IntelliSense support
)
```

### Professional IDE Support
Enhanced development experience with comprehensive type information:

- **Superior IntelliSense**: Advanced autocompletion and parameter hints
- **Go to Definition**: F12 shows clean type declarations instead of implementation
- **Enhanced Type Safety**: Static analysis and error detection with proper mixin support
- **Mixin System**: Advanced metaclass-based mixins with full type introspection

### Simplified GUI Components
No more complex wxPython constructors - just simple, intuitive classes:

```python
# Before (raw wxPython)
frame = wx.Frame(None, wx.ID_ANY, "Title", size=(800, 600))
panel = wx.Panel(frame)
button = wx.Button(panel, wx.ID_ANY, "Click", pos=(10, 10), size=(100, 30))

# After (apiwx)
app = apiwx.WrappedApp("MyApp")
frame = apiwx.WrappedWindow(app, title="Title", size=(800, 600))
panel = apiwx.WrappedPanel(frame)
button = apiwx.WrappedButton(panel, label="Click", pos=(10, 10), size=(100, 30))
```

### Easy Event Handling
Connect events with simple syntax:

```python
button = apiwx.WrappedButton(panel, label="Save")

def save_file(event):
    # Your save logic here
    apiwx.show_info("File saved successfully!")

# Easy event connection with slots
button.slots_on_click += save_file

# Or use the connect method
button.connect(apiwx.EVT_BUTTON, save_file)

# Enable/disable controls easily
button.enable()   # New in v0.3.2
button.disable()  # New in v0.3.2
```

### Built-in Message Boxes
Show messages and get user input with one line:

```python
# Simple messages
apiwx.show_info("Operation completed!")
apiwx.show_warning("Please check your input.")
apiwx.show_error("Something went wrong.")

# Get user input
name = apiwx.get_text_input("What's your name?", "User Input")
if name:
    apiwx.show_info(f"Hello, {name}!")

# Ask questions
if apiwx.ask_question("Do you want to save changes?"):
    save_changes()
```

### C#-Style File Dialogs
Open, save, and browse files with familiar C# dialog patterns:

```python
# OpenFileDialog - Single file selection
open_dialog = apiwx.OpenFileDialog()
open_dialog.title = "Open Document"
open_dialog.filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
open_dialog.initial_directory = "/home/user/documents"

if open_dialog.show_dialog() == apiwx.DialogResult.OK:
    filename = open_dialog.selected_filename
    print(f"Opening: {filename}")

# OpenFileDialog - Multiple file selection
open_dialog.multiselect = True
if open_dialog.show_dialog() == apiwx.DialogResult.OK:
    for filename in open_dialog.filenames:
        print(f"Selected: {filename}")

# SaveFileDialog
save_dialog = apiwx.SaveFileDialog()
save_dialog.title = "Save Document"
save_dialog.filter = "Text files (*.txt)|*.txt|Python files (*.py)|*.py"
save_dialog.filename = "document.txt"
save_dialog.overwrite_prompt = True

if save_dialog.show_dialog() == apiwx.DialogResult.OK:
    filename = save_dialog.selected_filename
    print(f"Saving to: {filename}")

# FolderBrowserDialog
folder_dialog = apiwx.FolderBrowserDialog()
folder_dialog.description = "Select output folder"
folder_dialog.show_new_folder_button = True

if folder_dialog.show_dialog() == apiwx.DialogResult.OK:
    folder = folder_dialog.selected_path
    print(f"Selected folder: {folder}")

# Quick convenience functions
result, filenames = apiwx.open_file_dialog(
    title="Quick Open", 
    filter="All files (*.*)|*.*", 
    multiselect=True
)

result, filename = apiwx.save_file_dialog(
    title="Quick Save", 
    filter="Text files (*.txt)|*.txt"
)

result, folder = apiwx.folder_browser_dialog(
    description="Select folder"
)
```

### Smart Button Behaviors with Mixin System
Add advanced behaviors with the powerful mixin system:

```python
# Button that disables itself after clicking (prevents double-clicks)
button = apiwx.WrappedButton[apiwx.SingleClickDisable](
    panel, label="Submit", disable_duration=2.0, auto_re_enable=True
)

# Button that requires double-click for confirmation
delete_btn = apiwx.WrappedButton[apiwx.DoubleClickOnly](
    panel, label="Delete", double_click_timeout=0.5
)

# Button with click confirmation guard
confirm_btn = apiwx.WrappedButton[apiwx.ClickGuard](
    panel, label="Delete All", guard_message="Click again to confirm"
)

# Check what mixins are applied (New in v0.3.2, updated in v0.5.2)
from apiwx.mixins_core import MixinsType
if MixinsType.hasmixins(type(button), apiwx.SingleClickDisable):
    print("Button has single-click disable behavior")
```

### Intelligent Text Positioning with StaticText Mixins (New in v0.5.6)
Automatically position text within parent windows using alignment mixins:

```python
# Import StaticText positioning components
from apiwx.mixins_statictext import LocateByParent, TextAlign

# Create aligned text using mixin
class AlignedText(apiwx.WrappedStaticText[LocateByParent]):
    pass

app = apiwx.WrappedApp("Text Positioning Demo")
window = apiwx.WrappedWindow(app, title="Alignment Demo", size=(400, 300))

# Center-aligned text using string shorthand
center_text = AlignedText(window, label="Centered Text", align="c")

# Top-right aligned text using enum
top_right_text = AlignedText(window, label="Top Right", align=TextAlign.TOPRIGHT)

# Bottom-left aligned text
bottom_left_text = AlignedText(window, label="Bottom Left", align="bl")

# Dynamic alignment changes
center_text.align = TextAlign.BOTTOMRIGHT  # Move to bottom-right
center_text.align = "tl"  # Move to top-left using string

# All nine alignment options available:
# "tl" (top-left), "t" (top), "tr" (top-right)
# "l" (left), "c" (center), "r" (right)  
# "bl" (bottom-left), "b" (bottom), "br" (bottom-right)

app.mainloop()
```

### Dynamic List Management with MutableListView (New in v0.5.7)
Create dynamic, scrollable list interfaces with automatic panel management:

```python
from apiwx import MutableListView, AbstractMutableListNode

# Create a custom node type for list items
class TaskNode(AbstractMutableListNode):
    def __init__(self, parent, task_data):
        super().__init__(parent)
        self.task_data = task_data
        
        # Create UI components for this task
        self.label = apiwx.WrappedStaticText(self, label=f"Task: {task_data['name']}")
        self.status_btn = apiwx.WrappedButton(self, label="Toggle", size=(60, 25))
        
        # Connect event
        self.status_btn.slots_on_click += self.toggle_status
        
        # Layout components
        sizer = apiwx.core._wx.BoxSizer(apiwx.core._wx.HORIZONTAL)
        sizer.Add(self.label, 1, apiwx.core._wx.EXPAND | apiwx.core._wx.ALL, 5)
        sizer.Add(self.status_btn, 0, apiwx.core._wx.ALL, 5)
        self.SetSizer(sizer)
    
    def to_node(self):
        """Return the underlying task data."""
        return self.task_data
        
    @classmethod
    def from_node(cls, parent, task_data):
        """Create a TaskNode from task data."""
        return cls(parent, task_data)
    
    def toggle_status(self, event):
        """Toggle task completion status."""
        self.task_data['completed'] = not self.task_data.get('completed', False)
        status = "✓" if self.task_data['completed'] else "○"
        self.label.SetLabel(f"{status} Task: {self.task_data['name']}")

# Create the application and window
app = apiwx.WrappedApp("Task Manager")
window = apiwx.WrappedWindow(app, title="Dynamic Task List", size=(500, 400))

# Create the mutable list view
task_list = MutableListView(
    window,
    size=(450, 300),
    pos=(25, 25),
    node_view_type=TaskNode,
    style=apiwx.styleflags.VSCROLL,  # Enable vertical scrolling
    scroll_rate=(5, 10)  # Scroll sensitivity
)

# Add some initial tasks
tasks = [
    {"name": "Write documentation", "completed": False},
    {"name": "Test new features", "completed": True},
    {"name": "Review code", "completed": False},
    {"name": "Deploy to production", "completed": False}
]

for task in tasks:
    task_list.append(task)

# Add new task button
add_btn = apiwx.WrappedButton(window, label="Add Task", pos=(25, 340), size=(100, 30))

def add_new_task(event):
    """Add a new task to the list."""
    import random
    new_task = {
        "name": f"New Task {random.randint(1, 1000)}",
        "completed": False
    }
    task_list.append(new_task)

add_btn.slots_on_click += add_new_task

# Remove completed tasks button
remove_btn = apiwx.WrappedButton(window, label="Remove Completed", pos=(140, 340), size=(130, 30))

def remove_completed(event):
    """Remove all completed tasks."""
    # Get all completed tasks
    completed_tasks = [node.to_node() for node in task_list.node_view_list 
                      if node.to_node().get('completed', False)]
    
    # Remove them from the list
    for task in completed_tasks:
        task_list.remove(task)

remove_btn.slots_on_click += remove_completed

app.mainloop()
```

### Advanced Component Detection
Automatic component detection and management with enhanced indexor search (v0.5.4):

```python
# App with automatic window detection
app = apiwx.WrappedApp[apiwx.Singleton, apiwx.DetectWindow]("MyApp")

# Window with automatic panel detection and sizing
window = apiwx.WrappedWindow[apiwx.DetectPanel, apiwx.ByPanelSize](
    app, title="Smart Window"
)

# Panel with automatic child detection
panel = apiwx.WrappedPanel[apiwx.DetectChildren](window)

# Window with panel transition support (New alias in v0.3.2)
transit_window = apiwx.WindowSizeTransitWithPanel(app, title="Transition Window")
```

#### New in v0.5.4: Child Indexor Search
Easily find and access dynamically created UI components:

```python
import apiwx

# Define app with multiple component types detection
DetectComponents = apiwx.AutoDetect[apiwx.WrappedWindow, apiwx.WrappedButton]

class MyApp(apiwx.WrappedApp[DetectComponents]):
    # Class-level components (detected automatically)
    main_window = apiwx.WrappedWindow
    help_window = apiwx.WrappedWindow
    
    def __init__(self):
        # Instance-level components (also detected)
        self.dialog_window = apiwx.WrappedWindow
        super().__init__("Component Detection Demo")
        
        # Search for specific component types
        window_indexors = self.search_child_indexor(apiwx.WrappedWindow)
        button_indexors = self.search_child_indexor(apiwx.WrappedButton)
        
        print(f"Found {len(window_indexors)} windows")  # 3 windows
        print(f"Found {len(button_indexors)} buttons")  # 0 buttons
        
        # Access specific components by indexor
        for indexor in window_indexors:
            window = self.children[indexor]
            print(f"Window: {window}")

# Singleton mixin example (returns tuple with single indexor)
DetectSinglePanel = apiwx.AutoDetect[apiwx.WrappedPanel]
class SinglePanelApp(apiwx.WrappedApp[DetectSinglePanel]):
    main_panel = apiwx.WrappedPanel
    
    def __init__(self):
        super().__init__("Single Panel App")
        panels = self.search_child_indexor(apiwx.WrappedPanel)
        assert len(panels) == 1  # Singleton - exactly one panel

# Multiton mixin example (returns tuple with multiple indexors)  
DetectMultipleButtons = apiwx.AutoDetect[apiwx.WrappedButton]
class MultiButtonApp(apiwx.WrappedApp[DetectMultipleButtons]):
    ok_button = apiwx.WrappedButton
    cancel_button = apiwx.WrappedButton
    help_button = apiwx.WrappedButton
    
    def __init__(self):
        super().__init__("Multi Button App")
        buttons = self.search_child_indexor(apiwx.WrappedButton)
        assert len(buttons) == 3  # Multiton - three buttons
        
        # Process all buttons
        for indexor in buttons:
            button = self.children[indexor]
            print(f"Button found: {button}")
```

### Enhanced Type Support with Mixin System
apiwx v0.5.2 includes a completely redesigned mixin system with full type support:

```python
# Full type hints and IDE support with working mixins
from apiwx import WrappedApp, WrappedWindow, WrappedButton, Singleton
from typing import Optional

# Singleton app with type safety
app: WrappedApp = WrappedApp[Singleton]("TypedApp")
window: WrappedWindow = WrappedWindow(app, title="Typed Window")

# Enhanced button with type checking and mixin introspection
button: WrappedButton = WrappedButton[apiwx.SingleClickDisable](
    parent=window,
    label="Click Me",
    size=(120, 40),
    pos=(10, 10),
    disable_duration=3.0
)

# Check applied mixins at runtime (Redesigned in v0.5.2)
if button.hasmixins(apiwx.SingleClickDisable):
    print("Single-click disable behavior is active")

# Get all mixins classes
mixins_list = button.__mixin_classes__
print(f"Applied mixins: {mixins_list}")
```

## Available Components

### Core GUI Components
- **WrappedApp** - Application container
- **WrappedWindow** - Main windows and frames
- **WrappedPanel** - Container panels
- **WrappedButton** - Clickable buttons
- **WrappedStaticText** - Text labels
- **WrappedTextBox** - Text input fields
- **WrappedCheckBox** - Checkboxes
- **WrappedListBox** - List selections
- **WrappedComboBox** - Dropdown selections
- **WrappedSlider** - Value sliders
- **And many more...**

### File Dialog Components (New in v0.5.3)
C#-style file dialogs with familiar APIs:
- **OpenFileDialog** - File selection for opening (single/multiple)
- **SaveFileDialog** - File selection for saving with overwrite protection
- **FolderBrowserDialog** - Folder/directory selection
- **DialogResult** - Result constants (OK, CANCEL, etc.)
- **Convenience functions** - `open_file_dialog()`, `save_file_dialog()`, `folder_browser_dialog()`

### Event System (Enhanced in v0.5.2)
- **Slots** - Event handling system for connecting callbacks and managing event slots

### Mixin System (Redesigned in v0.5.2)
Add advanced behaviors to components with the comprehensive mixin system:

#### Base Patterns
- **Singleton/Multiton** - Instance management patterns (using standardized mixins)
- **AutoDetect** - Automatic component detection and management
- **FixSize** - Fixed sizing behavior

#### Button Mixins  
- **SingleClickDisable** - Prevent double-clicking with auto re-enable
- **DoubleClickOnly** - Require double-click confirmation
- **ClickGuard** - Click confirmation prompts with customizable messages

#### StaticText Mixins (New in v0.5.6)
- **TextAlign** - Enumeration for nine text alignment positions
- **LocateByParent** - Automatic text positioning within parent window boundaries

#### Window & Panel Mixins
- **DetectPanel** - Automatic panel detection in windows
- **DetectChildren** - Child component detection in panels
- **WithBoarder** - Automatic border management
- **ByPanelSize** - Automatic window sizing based on panel content
- **SupportTransit** - Panel transition support
- **NotTransition** - Exclude panels from transition management

#### App Mixins
- **DetectWindow** - Automatic window detection in applications

#### Mixin Aliases (Enhanced in v0.5.5)
Comprehensive pre-built classes that combine common mixin behaviors with complete documentation:

**Application Classes:**
- **AppBase** - `WrappedApp[Singleton]` - Single instance applications
- **AppDetectWindow** - `WrappedApp[Singleton, DetectWindow]` - With automatic window detection

**Window Classes:**
- **WindowWithPanel** - `WrappedWindow[DetectPanel]` - Auto-detects child panels
- **WindowByPanelSize** - `WrappedWindow[DetectPanel, ByPanelSize]` - Sizes by panel content
- **WindowPanelTransit** - `WrappedWindow[SupportTransit]` - Panel transition support
- **WindowSizeTransitWithPanel** - `WrappedWindow[SupportTransit, ByPanelSize]` - Combined features

**Panel Classes:**
- **PanelDetectChildren** - `WrappedPanel[DetectChildren]` - Auto-detects child components  
- **PanelWithBoarder** - `WrappedPanel[WithBoarder]` - Built-in border drawing
- **PanelNoTransition** - `WrappedPanel[NotTransition]` - Excluded from transitions

**Button Classes:**
- **ButtonSingleClickDisable** - `WrappedButton[SingleClickDisable]` - Prevents double-clicks
- **ButtonDoubleClickOnly** - `WrappedButton[DoubleClickOnly]` - Requires double-click
- **ButtonClickGuard** - `WrappedButton[ClickGuard]` - Click confirmation protection

```python
# Easy instantiation with full type support and IntelliSense (v0.5.5)
from apiwx.mixins_alias import AppBase, WindowByPanelSize, PanelWithBoarder

app = AppBase("MyApp")
window = WindowByPanelSize(app, title="Auto-Sized Window") 
panel = PanelWithBoarder(
    window,
    boarder_color=(255, 0, 0),   # RGB tuple - fully typed parameters
    boarder_thickness=2,         # Integer - IntelliSense support
    boarder_offset=5             # Integer - Auto-completion
)
```

### Message Boxes & Dialogs
- **show_info()** - Information messages
- **show_warning()** - Warning messages
- **show_error()** - Error messages
- **ask_question()** - Yes/No questions
- **get_text_input()** - Text input dialog
- **get_number_input()** - Numeric input dialog
- **get_choice_input()** - Selection dialog

### Advanced Features
- **Enhanced Mixin System** - Add behaviors to components with proper introspection
- **Robust Logging System** - Built-in debug logging with multiple levels
- **Font Management** - Easy font handling and management
- **Color Constants** - Predefined color palette and utilities
- **Panel Transition Management** - Multi-panel visibility control with transitions
- **Type Introspection** - Runtime mixin detection with `hasmixins()` method
- **Convenient UI Controls** - `enable()` and `disable()` methods for all components

## Common Patterns

### Creating a Simple Form

```python
import apiwx

app = apiwx.WrappedApp("Form Example")
window = apiwx.WrappedWindow(app, title="User Form", size=(400, 300))
panel = apiwx.WrappedPanel(window)

# Form elements
name_label = apiwx.WrappedStaticText(panel, text="Name:", pos=(20, 20))
name_input = apiwx.WrappedTextBox(panel, pos=(80, 20), size=(200, 25))

email_label = apiwx.WrappedStaticText(panel, text="Email:", pos=(20, 60))
email_input = apiwx.WrappedTextBox(panel, pos=(80, 60), size=(200, 25))

submit_button = apiwx.WrappedButton(panel, label="Submit", pos=(150, 120))

def submit_form(event):
    name = name_input.text
    email = email_input.text
    
    if not name or not email:
        apiwx.show_warning("Please fill in all fields.")
        return
    
    apiwx.show_info(f"Form submitted!\nName: {name}\nEmail: {email}")

submit_button.slots_on_click += submit_form

app.mainloop()
```

### Working with Enhanced Type Declarations and Mixins (v0.5.5)

```python
from apiwx.mixins_alias import AppBase, WindowWithPanel, PanelDetectChildren
from typing import Optional

# Type-aware development with convenient aliases
app: AppBase = AppBase("MyApp")
window: WindowWithPanel = WindowWithPanel(app, title="Type Demo")

# IDE provides full IntelliSense and error checking
def create_smart_button(parent: PanelDetectChildren, 
                       label: str,
                       callback: Optional[callable] = None) -> apiwx.WrappedButton:
    # Use alias for enhanced button behavior
    from apiwx.mixins_alias import ButtonSingleClickDisable
    
    button = ButtonSingleClickDisable(
        parent, label=label, pos=(10, 10), disable_duration=2.0
    )
    
    if callback:
        button.slots_on_click += callback
    
    # Check mixins at runtime
    if button.hasmixins(apiwx.SingleClickDisable):
        print(f"Button '{label}' has single-click disable protection")
    
    return button

# Use convenience methods
def toggle_button_state(button: apiwx.WrappedButton):
    if button.is_enabled():
        button.disable()
    else:
        button.enable()
```

### Using Enhanced Mixins for Advanced Functionality (v0.5.5)

```python
from apiwx.mixins_alias import AppBase, WindowWithPanel, PanelDetectChildren
from apiwx.mixins_alias import ButtonSingleClickDisable, ButtonDoubleClickOnly, ButtonClickGuard

app = AppBase("Mixins Demo")
window = WindowWithPanel(app, title="Advanced Buttons")
panel = PanelDetectChildren(window)

# Button that disables after click to prevent double-submission
submit_btn = ButtonSingleClickDisable(
    panel, 
    label="Submit Form", 
    pos=(10, 10),
    disable_duration=3.0,
    auto_re_enable=True
)

# Button requiring double-click for dangerous operations
delete_btn = ButtonDoubleClickOnly(
    panel, 
    label="Delete All", 
    pos=(10, 50),
    double_click_timeout=0.5
)

# Button with confirmation guard
reset_btn = ButtonClickGuard(
    panel, 
    label="Reset Data", 
    pos=(10, 90),
    guard_message="Click again to confirm reset"
)

# Runtime mixin introspection
def check_button_behaviors():
    buttons = [submit_btn, delete_btn, reset_btn]
    
    for btn in buttons:
        print(f"Button '{btn.text}' mixins:")
        if btn.hasmixins(apiwx.SingleClickDisable):
            print("  - Has single-click disable")
        if btn.hasmixins(apiwx.DoubleClickOnly):
            print("  - Requires double-click")
        if btn.hasmixins(apiwx.ClickGuard):
            print("  - Has click guard")

# Window with panel transition support
from apiwx.mixins_alias import WindowSizeTransitWithPanel
transit_window = WindowSizeTransitWithPanel(
    app, title="Transition Demo", size=(400, 300)
)

app.mainloop()
```

### Progress Dialog for Long Operations

```python
import apiwx
import time

def long_operation():
    progress = apiwx.ProgressMessageBox("Processing", "Please wait...", maximum=100)
    
    for i in range(100):
        time.sleep(0.05)  # Simulate work
        progress.update(i + 1, f"Processing item {i + 1}/100")
        if progress.was_cancelled():
            break
    
    progress.close()
    apiwx.show_info("Operation completed!")

# Call this from a button click or menu
```

### Using Colors and Styles

```python
import apiwx

app = apiwx.WrappedApp("Styled App")
window = apiwx.WrappedWindow(app, title="Colors Demo", size=(400, 300))
panel = apiwx.WrappedPanel(window)

# Using built-in colors
panel.color_background = apiwx.Colour.LIGHT_GREY
title = apiwx.WrappedStaticText(panel, text="Welcome!", pos=(150, 50))
title.color_text = apiwx.Colour.DARK_BLUE

# Styled button
button = apiwx.WrappedButton(panel, label="Colorful Button", pos=(130, 100))
button.color_background = apiwx.Colour.LIGHT_GREEN

app.mainloop()
```

## Learning More

### Type Declaration Benefits

apiwx v0.5.2 includes comprehensive type stubs with redesigned mixin system:

- **Perfect IDE Integration**: Go to Definition (F12) shows clean type interfaces
- **Enhanced Development Speed**: Superior autocompletion and parameter hints  
- **Advanced Error Prevention**: Static type checking with mixin support
- **Runtime Introspection**: Working `hasmixins()` method for runtime type checking
- **Living Documentation**: Type signatures serve as built-in API documentation

### Module Organization

- **`core.py`** - Main wrapper classes with enhanced UI controls (`enable()`, `disable()`)
- **`message.py`** - Message boxes and dialogs with comprehensive options
- **`mixins_*.py`** - Mixin behaviors for different component types (fixed system)
- **`mixins_core.py`** - Core mixins system with working `hasmixins()` method
- **`mixins_alias.py`** - Convenient type aliases for rapid development (New in v0.5.5)
- **`debug.py`** - Advanced logging and debugging utilities
- **`colors.py`** - Color constants and utilities
- **`fontmanager.py`** - Font management system
- **`paneltransmodel.py`** - Panel transition management (updated with enhanced documentation)
- **`stubs/`** - Type declaration files (.pyi) for superior IDE support

### Documentation
- Each module contains detailed docstrings
- Use Python's `help()` function for detailed information:
  ```python
  import apiwx
  help(apiwx.WrappedButton)
  help(apiwx.show_info)
  ```

## Why Choose apiwx?

- **Beginner-Friendly** - Simplified API that's easy to learn
- **Highly Productive** - Write less code, get more done with smart defaults
- **Professional Code Quality** - 100% PEP 8/257 compliant for enterprise standards (v0.5.0)
- **Robustly Type-Safe** - Comprehensive type declarations with working mixin system
- **Extremely Flexible** - Use simple wrappers or advanced mixin behaviors
- **Thoroughly Modern** - Contemporary Python patterns and superior IDE support
- **Rock-Solid Reliable** - Built on the mature wxPython framework with extensive testing
- **Desktop-Focused** - Designed specifically for desktop GUI applications
- **Runtime Introspection** - Full mixin support with `hasmixins()` method
- **Python 3.12 Ready** - Fully tested and optimized for the latest Python versions
- **Internationally Accessible** - Complete documentation available in multiple languages
- **Enterprise Ready** - Professional coding standards and comprehensive quality assurance

## Advanced Usage

For complex applications, explore:
- **Enhanced Mixin System** for component behavior customization with runtime introspection
- **Professional Type Declarations** for superior IDE support and development experience
- **Panel Transition Management** for multi-view applications with smooth transitions
- **Advanced Debug Logging** for development and troubleshooting with multiple log levels
- **Smart Font Management** for consistent typography across components
- **Rich Message Dialogs** for comprehensive user interaction and feedback
- **Component Introspection** using `hasmixins()` for runtime behavior detection
- **Convenient UI Controls** with `enable()` and `disable()` methods
- **Python 3.12 Features** including typing.override decorator and modern type syntax
- **Comprehensive Testing Framework** with 9-category test coverage for reliability assurance

## Examples

Check the project repository for complete examples and tutorials showing:
- Simple desktop applications with enhanced controls
- Form handling and validation with smart behaviors
- Multi-panel applications with transition management
- Advanced component behaviors using the redesigned mixin system
- Type-safe development patterns with runtime introspection
- Integration with other Python libraries
- Real-world usage of `hasmixins()` method for dynamic behavior detection
- Python 3.12 compatibility examples with modern language features
- Comprehensive testing patterns for GUI applications

### Compatibility and Testing

### Python Version Support
- **Python 3.11**: Full support (recommended baseline)
- **Python 3.12**: Fully tested and supported with comprehensive test suite
- **Python 3.13**: Ready for testing (compatibility framework in place)

### Code Quality Standards (New in v0.5.0)
apiwx v0.5.0 achieves the highest code quality standards:

- **PEP 8 Compliance**: 100% adherence to Python style guidelines
- **PEP 257 Compliance**: Complete docstring convention compliance
- **Line Length Standards**: All code follows 79-character limit
- **Consistent Formatting**: Uniform indentation and spacing throughout
- **Professional Documentation**: Enhanced docstrings with proper formatting
- **Type Safety**: Maintained full type annotation integrity during compliance updates

### Testing Framework
apiwx includes a comprehensive testing framework with 9 major test categories:

1. **Core Components Testing** - Basic GUI component functionality
2. **Mixin System Testing** - Advanced behavior system validation
3. **Message System Testing** - Dialog and notification functionality
4. **Event Handling Testing** - User interaction and event processing
5. **Type System Testing** - Type annotations and IDE support
6. **Import System Testing** - Module loading and dependency management
7. **UI Control Testing** - enable/disable and state management
8. **Panel Management Testing** - Multi-panel and transition systems
9. **Python Version Compatibility** - Version-specific feature testing

All tests maintain 100% pass rate across supported Python versions, ensuring reliable cross-version compatibility and professional code quality standards.

## Latest Updates

### Version 0.5.5 (Current) - October 11, 2025
- **COMPREHENSIVE TYPE ALIASES**: New `mixins_alias.py` module with 12 convenient type aliases (AppBase, WindowWithPanel, etc.)
- **COMPLETE DOCUMENTATION**: All type aliases include detailed docstrings, usage examples, and parameter documentation
- **DEVELOPMENT EFFICIENCY**: Pre-configured classes eliminate repetitive mixin syntax for common patterns
- **ENHANCED PANEL TRANSITIONS**: Improved `paneltransmodel.py` with better documentation and cleaner API patterns
- **BETTER DEVELOPER EXPERIENCE**: IntelliSense support for mixin parameters with real instantiable classes
- **RAPID PROTOTYPING**: Quick access to sophisticated UI patterns through simple imports

### Version 0.5.4
- **CHILD INDEXOR SEARCH**: New `search_child_indexor()` method for AutoDetect mixin with singleton/multiton support
- **ENHANCED INSTANCE DETECTION**: Improved runtime detection of instance attributes in addition to class attributes
- **DEVELOPER FLEXIBILITY**: Easy access to dynamically created UI components through indexor tuples
- **COMPREHENSIVE TYPE SUPPORT**: Full type stubs for enhanced IDE integration and autocomplete

### Version 0.5.0
- **CODE QUALITY EXCELLENCE**: Achieved 100% PEP 8 and PEP 257 compliance across all source files
- **COMPREHENSIVE PEP COMPLIANCE**: Fixed 25 PEP 8 violations (E501 line length) in 18 core modules
- **ENHANCED DOCUMENTATION**: Improved docstring quality and code readability throughout
- **FULL TESTING VERIFICATION**: All test suites pass with 100% success rate (11/11 comprehensive tests)
- **ROBUST FUNCTIONALITY**: Maintained complete functional compatibility while improving code quality
- **PROFESSIONAL STANDARDS**: Consistent coding style and documentation standards implementation
- **MODERN PYTHON PRACTICES**: Enhanced type annotations and coding patterns following latest PEP guidelines

### Version 0.4.0
- **PYTHON 3.12 SUPPORT**: Comprehensive testing and full compatibility with Python 3.12
- **EXTENSIVE TESTING**: Added comprehensive test suite covering all 9 major functionality areas
- **INTERNATIONALIZATION**: Added complete English documentation for international developers
- **COMPATIBILITY VERIFICATION**: All Python 3.12 specific features tested and confirmed working
- **ENHANCED RELIABILITY**: Rigorous testing framework ensures consistent behavior across Python versions
- **DOCUMENTATION EXPANSION**: Complete technical documentation in both Japanese and English
- **MODERN PYTHON FEATURES**: Support for Python 3.12's typing.override decorator and PEP 695 syntax

### Version 0.3.3
- **CRITICAL FIX**: Resolved `__init__.py` import structure and class name inconsistencies
- **IMPROVEMENT**: Enhanced error handling and module initialization
- **TESTING**: Added comprehensive compatibility testing framework
- **STABILITY**: Improved package reliability and installation process

### Version 0.3.2
- **CRITICAL REDESIGN**: Redesigned mixin system - `hasmixins()` method with improved architecture
- **CRITICAL FIX**: Fixed `__mixin_classes__` attribute being properly set during creation
- **ENHANCEMENT**: Added `enable()` and `disable()` convenience methods to all UI components
- **IMPROVEMENT**: Reorganized import structure for better reliability and error handling
- **NEW ALIAS**: Added `WindowSizeTransitWithPanel` for combined window behaviors
- **CLEANUP**: Removed deprecated `DetectButton` and cleaned up mixin aliases
- **TESTING**: Added comprehensive test suite with 100% pass rate
- **COMPATIBILITY**: Maintained full backward compatibility while fixing core issues

### Version 0.3.1
- Added comprehensive type declaration files (.pyi)
- Enhanced VS Code and IDE integration
- Improved "Go to Definition" functionality
- PEP 561 compliance for type checkers
- Better development experience with full IntelliSense support

## International Documentation

apiwx v0.4.0 includes comprehensive documentation in multiple languages:
- **Japanese**: Complete technical documentation and development notes
- **English**: Full translations for international developer community
- **Technical Memos**: Detailed compatibility notes and implementation guides
- **Quick Reference**: Rapid access guides for common development patterns

This ensures apiwx is accessible to developers worldwide, with complete technical documentation available in both Japanese and English.

## License

MIT License - free for both personal and commercial use.
