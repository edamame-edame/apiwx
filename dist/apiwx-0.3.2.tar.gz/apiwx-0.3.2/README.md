

# apiwx

**apiwx** is a modern, user-friendly wrapper for wxPython that makes GUI development easier and more intuitive. It provides simplified APIs, automatic component management, powerful features like generics and message boxes, and comprehensive type declaration files for better IDE support.

## Quick Start

### Installation

```bash
pip install apiwx
```

### Requirements

- Python 3.13 or higher
- wxPython 4.2.0 or higher (automatically installed with apiwx)

### Your First App

```python
import apiwx

# Create a simple app with just a few lines
app = apiwx.WrappedApp("My First App")
window = apiwx.WrappedWindow(app, title="Hello World", size=(400, 300))
panel = apiwx.WrappedPanel(window)
button = apiwx.WrappedButton(panel, label="Click Me!", pos=(150, 100))

# Add button functionality
def on_click(event):
    apiwx.show_info("Hello from apiwx!")

button.slots_on_click += on_click

app.mainloop()
```

## Key Features

### Enhanced IDE Support (New in v0.3.1)
apiwx now includes comprehensive type declaration files (.pyi) that provide:

- **Better IntelliSense**: Improved autocompletion and parameter hints
- **Go to Definition**: F12 in VS Code shows clean type declarations instead of implementation details
- **Type Safety**: Enhanced static analysis and error detection during development
- **PEP 561 Compliance**: Full compatibility with mypy, pyright, and other type checkers

### Simplified GUI Components
No more complex wxPython constructors - just simple, intuitive classes:

```python
# Before (raw wxPython)
frame = wx.Frame(None, wx.ID_ANY, "Title", size=(800, 600))
panel = wx.Panel(frame)
button = wx.Button(panel, wx.ID_ANY, "Click", pos=(10, 10), size=(100, 30))

# After (apiwx)
app = apiwx.WrappedApp("MyApp")
frame = apiwx.WrappedWindow(app, title="Title", size=(800, 600))
panel = apiwx.WrappedPanel(frame)
button = apiwx.WrappedButton(panel, label="Click", pos=(10, 10), size=(100, 30))
```

### Easy Event Handling
Connect events with simple syntax:

```python
button = apiwx.WrappedButton(panel, label="Save")

def save_file(event):
    # Your save logic here
    apiwx.show_info("File saved successfully!")

# Easy event connection
button.slots_on_click += save_file
```

### Built-in Message Boxes
Show messages and get user input with one line:

```python
# Simple messages
apiwx.show_info("Operation completed!")
apiwx.show_warning("Please check your input.")
apiwx.show_error("Something went wrong.")

# Get user input
name = apiwx.get_text_input("What's your name?", "User Input")
if name:
    apiwx.show_info(f"Hello, {name}!")

# Ask questions
if apiwx.ask_question("Do you want to save changes?"):
    save_changes()
```

### Smart Button Behaviors
Add advanced behaviors with generics:

```python
# Button that disables itself after clicking (prevents double-clicks)
button = apiwx.WrappedButton[apiwx.SingleClickDisable](
    panel, label="Submit", disable_duration=2.0
)

# Button that requires double-click for confirmation
delete_btn = apiwx.WrappedButton[apiwx.DoubleClickOnly](
    panel, label="Delete", double_click_timeout=0.5
)

# Button with click confirmation
confirm_btn = apiwx.WrappedButton[apiwx.ClickGuard](
    panel, label="Delete All", guard_message="Click again to confirm"
)
```

### Comprehensive Type Support
apiwx includes complete type declaration files that work seamlessly with:

```python
# Full type hints and IDE support
from apiwx import WrappedApp, WrappedWindow, WrappedButton
from typing import Optional

app: WrappedApp = WrappedApp("TypedApp")
window: WrappedWindow = WrappedWindow(app, title="Typed Window")

# IDE shows full parameter information and type checking
button: WrappedButton = WrappedButton(
    parent=window.main_panel,
    label="Click Me",
    size=(120, 40),
    pos=(10, 10)
)
```

## Available Components

### Core GUI Components
- **WrappedApp** - Application container
- **WrappedWindow** - Main windows and frames
- **WrappedPanel** - Container panels
- **WrappedButton** - Clickable buttons
- **WrappedStaticText** - Text labels
- **WrappedTextBox** - Text input fields
- **WrappedCheckBox** - Checkboxes
- **WrappedListBox** - List selections
- **WrappedComboBox** - Dropdown selections
- **WrappedSlider** - Value sliders
- **And many more...**

### Generics System
Add advanced behaviors to components:

- **AutoDetect** - Automatic component detection
- **FixSize** - Fixed sizing behavior  
- **Singleton/Multiton** - Instance management patterns
- **SingleClickDisable** - Prevent double-clicking
- **DoubleClickOnly** - Require double-click confirmation
- **ClickGuard** - Click confirmation prompts
- **WithBoarder** - Automatic border management
- **DetectChildren** - Child component detection

### Message Boxes & Dialogs
- **show_info()** - Information messages
- **show_warning()** - Warning messages
- **show_error()** - Error messages
- **ask_question()** - Yes/No questions
- **get_text_input()** - Text input dialog
- **get_number_input()** - Numeric input dialog
- **get_choice_input()** - Selection dialog

### Advanced Features
- **Generics System** - Add behaviors to components
- **Logging System** - Built-in debug logging
- **Font Management** - Easy font handling
- **Color Constants** - Predefined color palette
- **Panel Management** - Multi-panel visibility control

## Common Patterns

### Creating a Simple Form

```python
import apiwx

app = apiwx.WrappedApp("Form Example")
window = apiwx.WrappedWindow(app, title="User Form", size=(400, 300))
panel = apiwx.WrappedPanel(window)

# Form elements
name_label = apiwx.WrappedStaticText(panel, text="Name:", pos=(20, 20))
name_input = apiwx.WrappedTextBox(panel, pos=(80, 20), size=(200, 25))

email_label = apiwx.WrappedStaticText(panel, text="Email:", pos=(20, 60))
email_input = apiwx.WrappedTextBox(panel, pos=(80, 60), size=(200, 25))

submit_button = apiwx.WrappedButton(panel, label="Submit", pos=(150, 120))

def submit_form(event):
    name = name_input.text
    email = email_input.text
    
    if not name or not email:
        apiwx.show_warning("Please fill in all fields.")
        return
    
    apiwx.show_info(f"Form submitted!\nName: {name}\nEmail: {email}")

submit_button.slots_on_click += submit_form

app.mainloop()
```

### Working with Type Declarations

```python
import apiwx
from typing import Optional

# Type-aware development
app: apiwx.WrappedApp = apiwx.WrappedApp("MyApp")
window: apiwx.WrappedWindow = apiwx.WrappedWindow(app, title="Type Demo")

# IDE provides full IntelliSense and error checking
def create_button_with_types(parent: apiwx.WrappedPanel, 
                           label: str,
                           callback: Optional[callable] = None) -> apiwx.WrappedButton:
    button = apiwx.WrappedButton(parent, label=label, pos=(10, 10))
    if callback:
        button.slots_on_click += callback
    return button
```

### Using Generics for Enhanced Functionality

```python
import apiwx

app = apiwx.WrappedApp("Generics Demo")
window = apiwx.WrappedWindow(app, title="Advanced Buttons")
panel = apiwx.WrappedPanel(window)

# Button that disables after click to prevent double-submission
submit_btn = apiwx.WrappedButton[apiwx.SingleClickDisable](
    panel, label="Submit Form", pos=(10, 10)
)

# Button requiring double-click for dangerous operations
delete_btn = apiwx.WrappedButton[apiwx.DoubleClickOnly](
    panel, label="Delete All", pos=(10, 50)
)

# Button with confirmation guard
reset_btn = apiwx.WrappedButton[apiwx.ClickGuard](
    panel, label="Reset Data", pos=(10, 90)
)

app.mainloop()
```

### Progress Dialog for Long Operations

```python
import apiwx
import time

def long_operation():
    progress = apiwx.ProgressMessageBox("Processing", "Please wait...", maximum=100)
    
    for i in range(100):
        time.sleep(0.05)  # Simulate work
        progress.update(i + 1, f"Processing item {i + 1}/100")
        if progress.was_cancelled():
            break
    
    progress.close()
    apiwx.show_info("Operation completed!")

# Call this from a button click or menu
```

### Using Colors and Styles

```python
import apiwx

app = apiwx.WrappedApp("Styled App")
window = apiwx.WrappedWindow(app, title="Colors Demo", size=(400, 300))
panel = apiwx.WrappedPanel(window)

# Using built-in colors
panel.color_background = apiwx.Colour.LIGHT_GREY
title = apiwx.WrappedStaticText(panel, text="Welcome!", pos=(150, 50))
title.color_text = apiwx.Colour.DARK_BLUE

# Styled button
button = apiwx.WrappedButton(panel, label="Colorful Button", pos=(130, 100))
button.color_background = apiwx.Colour.LIGHT_GREEN

app.mainloop()
```

## Learning More

### Type Declaration Benefits

apiwx v0.3.1+ includes comprehensive type stubs that provide:

- **IDE Integration**: Go to Definition (F12) shows clean type interfaces
- **Development Speed**: Enhanced autocompletion and parameter hints  
- **Error Prevention**: Static type checking catches issues before runtime
- **Documentation**: Type signatures serve as built-in API documentation

### Module Organization

- **`core.py`** - Main wrapper classes and core functionality
- **`message.py`** - Message boxes and dialogs  
- **`generics_*.py`** - Generic behaviors for different component types
- **`debug.py`** - Logging and debugging utilities
- **`colors.py`** - Color constants and utilities
- **`fontmanager.py`** - Font management system
- **`stubs/`** - Type declaration files (.pyi) for IDE support

### Documentation
- Each module contains detailed docstrings
- Use Python's `help()` function for detailed information:
  ```python
  import apiwx
  help(apiwx.WrappedButton)
  help(apiwx.show_info)
  ```

## Why Choose apiwx?

- **Beginner-Friendly** - Simplified API that's easy to learn
- **Productive** - Write less code, get more done  
- **Type-Safe** - Comprehensive type declarations for better development experience
- **Flexible** - Use simple wrappers or advanced generic behaviors
- **Modern** - Contemporary Python patterns and full IDE support
- **Reliable** - Built on the mature wxPython framework
- **Focused** - Designed specifically for desktop GUI applications

## Advanced Usage

For complex applications, explore:
- **Generics System** for component behavior customization
- **Type Declarations** for enhanced IDE support and development experience
- **Panel Management** for multi-view applications  
- **Debug Logging** for development and troubleshooting
- **Font Management** for consistent typography
- **Message Dialogs** for user interaction and feedback

## Examples

Check the project repository for complete examples and tutorials showing:
- Simple desktop applications
- Form handling and validation
- Multi-panel applications  
- Advanced component behaviors using generics
- Type-safe development patterns
- Integration with other Python libraries

## Latest Updates

### Version 0.3.1
- Added comprehensive type declaration files (.pyi)
- Enhanced VS Code and IDE integration
- Improved "Go to Definition" functionality
- PEP 561 compliance for type checkers
- Better development experience with full IntelliSense support

## License

MIT License - free for both personal and commercial use.
