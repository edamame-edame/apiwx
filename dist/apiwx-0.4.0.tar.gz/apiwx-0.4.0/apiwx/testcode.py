from __init__ import *


class TestApp(AppDetectWindow):
    def __init__(self):
        super().__init__(
            name="APIWX Test Application"
        )


    class TestWindow(WindowSizeTransitWithPanel[Singleton]):
        def __init__(self, app: 'TestApp'):
            super().__init__(
                app,
                title="Test Window",
                size=(400, 300),
                pos=(100, 100),
            )

            self.show()


        def open_panel1(self, *args, **kwds):
            self.panel_trans.trans(self.child_1)


        def open_panel2(self, *args, **kwds):
            self.panel_trans.trans(self.child_2)


        class TestTabPanel(PanelNoTransition[DetectChildren, Singleton]):
            def __init__(self, parent: 'TestApp.TestWindow'):
                super().__init__(
                    parent=parent,
                    size=(400, 40),
                    pos=(0, 0),
                )

            class TestButton1(ButtonClickGuard[Singleton]):
                def __init__(self, parent: 'TestApp.TestWindow.TestTabPanel'):
                    super().__init__(
                        parent=parent,
                        label="Click Me",
                        size=(100, 30),
                        pos=(5, 5),
                    )

                    self.disable()

                    self.slots_on_click += parent.Parent.open_panel1

                    self.slots_on_click += lambda *a, **k: parent.TestButton2.instance.enable()

            
            class TestButton2(ButtonClickGuard[Singleton]):
                def __init__(self, parent: 'TestApp.TestWindow.TestTabPanel'):
                    super().__init__(
                        parent=parent,
                        label="Click Me",
                        size=(100, 30),
                        pos=(110, 5),
                    )

                    self.slots_on_click += parent.Parent.open_panel2

                    self.slots_on_click += lambda *a, **k: parent.TestButton1.instance.enable()
        

        class TestTransPanel1(PanelDetectChildren[Singleton]):
            def __init__(self, parent: 'TestApp.TestWindow'):
                super().__init__(
                    parent=parent,
                    pos=(0, 40),
                    size=(400, 260),
                )

            class TestStaticText(WrappedStaticText):
                def __init__(self, parent: 'TestApp.TestWindow.TestTransPanel1'):
                    super().__init__(
                        parent=parent,
                        label="This is a static text in Panel 1",
                        pos=(0, 0),
                        size=parent.size,
                    )
        
        class TestTransPanel2(PanelDetectChildren[Singleton]):
            def __init__(self, parent: 'TestApp.TestWindow'):
                super().__init__(
                    parent=parent,
                    size=(400, 260),
                    pos=(0, 40),
                )

            class TestStaticText(WrappedStaticText):
                def __init__(self, parent: 'TestApp.TestWindow.TestTransPanel2'):
                    super().__init__(
                        parent=parent,
                        label="This is a static text in Panel 2",
                        pos=(0, 0),
                        size=parent.size,
                    )


if __name__ == "__main__":
    app = TestApp()
    
    app.mainloop()